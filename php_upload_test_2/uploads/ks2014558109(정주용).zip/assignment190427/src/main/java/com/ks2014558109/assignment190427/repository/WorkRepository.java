package com.ks2014558109.assignment190427.repository;

import com.ks2014558109.assignment190427.domain.Work;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WorkRepository extends JpaRepository<Work,Long> {
}
