package com.ks2014558109.assignment190427;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment190427Application {

    public static void main(String[] args) {
        SpringApplication.run(Assignment190427Application.class, args);
    }

}
