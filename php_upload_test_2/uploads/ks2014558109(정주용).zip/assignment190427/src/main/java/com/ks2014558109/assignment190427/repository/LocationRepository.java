package com.ks2014558109.assignment190427.repository;

import com.ks2014558109.assignment190427.domain.Location;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocationRepository extends JpaRepository<Location,Long> {
}
