package com.ks2014558109.assignment190427.repository;

import com.ks2014558109.assignment190427.domain.Profile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfileRepository extends JpaRepository<Profile,Long> {
}
